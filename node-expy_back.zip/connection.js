var connection = mysql.createConnection({
	host     : 'localhost',
	user     : 'developer',
	password : 'Developer@2021',
	database : 'expy',	
	port : '3306',
	multipleStatements: true,
	charset : 'utf8mb4'
});
