exports.getDateTime = function () {
    return Date();
  };